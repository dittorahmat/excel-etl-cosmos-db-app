# Excel ETL Application - VPS Deployment

This directory contains the built application ready for deployment to a VPS.

## Contents
- `frontend/` - Built React frontend application
- `backend/` - Built Node.js backend application
- `package.json` - Deployment package configuration
- `.env.example` - Example environment configuration (copy to `.env` and customize)
- `start.sh` - Startup script
- `ecosystem.config.cjs` - PM2 configuration
- `Dockerfile` - Docker configuration
- `docker-compose.yml` - Docker Compose configuration
- `DOCKER-README.md` - Docker deployment instructions

## Deployment Instructions

### Prerequisites
- Node.js 16+ installed on your VPS
- npm or yarn package manager

### Quick Deploy Steps

1. **Transfer this directory to your VPS**

2. **Create environment configuration**:
   ```bash
   cp .env.example .env
   # Edit .env with your Azure configuration
   ```

3. **Install dependencies**:
   ```bash
   npm install
   ```

4. **Start the application**:
   ```bash
   ./start.sh
   ```

### Environment Configuration

Before starting the application, you must create a `.env` file with your Azure configuration:

```bash
# Copy the example configuration
cp .env.example .env

# Edit the .env file with your Azure settings
nano .env
```

Required configuration includes:
- Azure AD Application (Client) ID
- Azure AD Directory (Tenant) ID
- Azure Cosmos DB Endpoint and Key
- Azure Storage Account settings

### Accessing the Application

Once started, the application will be available at:
- Frontend: http://your-server-ip:3001
- Backend API: http://your-server-ip:3001/api/

### Using PM2 for Production

For production deployments, we recommend using PM2:

```bash
# Install PM2 globally
npm install -g pm2

# Start the application with PM2
pm2 start ecosystem.config.cjs

# Save the PM2 configuration
pm2 save

# Set up PM2 to start on boot
pm2 startup
```

### Using Docker

Alternatively, you can deploy using Docker:

```bash
# Create .env file with your configuration
cp .env.example .env
# Edit .env with your Azure settings

# Build and run with Docker Compose
docker-compose up -d
```

See `DOCKER-README.md` for detailed Docker deployment instructions.

## Troubleshooting

If you encounter any issues:

1. **Check Logs**: Look at the console output when starting the application
2. **Verify Environment Variables**: Ensure all required variables are set in `.env`
3. **Check File Permissions**: Ensure the application has read access to all files
4. **Verify Ports**: Ensure port 3001 (or your configured port) is not blocked by firewall

## Support

For additional support, refer to the main documentation or contact the development team.